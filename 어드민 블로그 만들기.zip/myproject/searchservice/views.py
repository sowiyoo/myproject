from django.shortcuts import render
from django.contrib.auth.models import User
from .models import Post


def index(request):
    posts = Post.objects.all().order_by('-pk')
    return render(
        request,
        'searchservice/index.html',
        {
            'posts': posts,
        }
    )

