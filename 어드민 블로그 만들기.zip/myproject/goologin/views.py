from django.contrib import auth
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.shortcuts import render, redirect


def goologin(request):
    template_name = 'goologin/home.html'
    return render(request, template_name)

    
def logout(request):
    template_name = 'goologin/logout.html'
    return render(request, template_name)



# home
#def logout(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            auth.logout(request, user)
            return redirect('board')
        else:
            return render(request, 'logout.html', {'error': 'username or password is incorrect.'})
    else:
        return render(request, 'logout.html')