from django.urls import path, include
from .views import *
from . import views


urlpatterns = [
    path('', views.goologin, name = "home"),
    path('', views.logout, name = "logout"),
]
